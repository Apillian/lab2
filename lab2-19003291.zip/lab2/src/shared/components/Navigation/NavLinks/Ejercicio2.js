import React from "react";

//importamos lista de usuarios.

const Ejercicio2 = () => {

    return(
        <h1>Hola mi preng </h1>
        
    );
}

export default Ejercicio2;