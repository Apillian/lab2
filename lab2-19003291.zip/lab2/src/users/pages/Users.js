import React from "react";

//importamos lista de usuarios.

const Users = () => {

    return(
        <h1>.sfdsdfsgsg</h1>
    );
}

export default Users;